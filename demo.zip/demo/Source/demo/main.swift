import Foundation
import AppKit

func main() {
    // 1. 动态库加载模块
    typealias ProcessImageFunction = @convention(c) (UnsafeMutablePointer<UInt8>?, Int32, Int32, Int32) -> UnsafeMutablePointer<UInt8>?

    // 加载动态库
    let handle = dlopen("/Users/gongyong/Desktop/Keyi/test_ws/image_process/build/libImage.dylib", RTLD_LAZY)
    if handle == nil {
        print("Failed to load library: \(String(cString: dlerror()))")
        exit(1)
    } else {
        print("Library loaded successfully")
    }

    // 获取函数地址
    let processImageFunctionPointer = dlsym(handle, "processImage")
    if processImageFunctionPointer == nil {
        print("Failed to find function: \(String(cString: dlerror()))")
        dlclose(handle)
        exit(1)
    } else {
        print("Function 'processImage' found successfully")
    }

    // 将指针转换为函数指针类型
    let processImageFunction = unsafeBitCast(processImageFunctionPointer, to: ProcessImageFunction.self)

    // 2. 加载图像，并且调用动态库处理
    let filePath = "/Users/gongyong/Desktop/Keyi/test_ws/demo/Source/demo/face.png"
    let outputPath = "/Users/gongyong/Desktop/Keyi/test_ws/demo/Source/demo/output.png"

    if let (pixelData, width, height, bytesPerRow) = loadPNGImage(from: filePath) {
        print("Image loaded successfully with dimensions: \(width) x \(height), bytesPerRow: \(bytesPerRow)")

        // 调用 C+ 图像处理函数
        let processedPixelData = processImageFunction(pixelData, Int32(width), Int32(height), Int32(bytesPerRow))
        if processedPixelData == nil {
            print("Image processing failed: processImage returned nil")
        } else {
            print("Image processed successfully")

            // 保存处理后的图像
            savePNGImage(to: outputPath, pixelData: processedPixelData, width: width, height: height, bytesPerRow: bytesPerRow)

            // 打印输出图像的长宽
            print("Output image dimensions: \(width) x \(height)")
        }

        // 释放动态分配的内存
        free(processedPixelData)
    } else {
        print("Failed to load image from \(filePath)")
    }

    // 关闭动态库
    dlclose(handle)
    print("Library closed successfully")
}

// 加载 PNG 图像的辅助函数
func loadPNGImage(from path: String) -> (UnsafeMutablePointer<UInt8>?, Int, Int, Int)? {
    print("Loading image from \(path)")
    guard let image = NSImage(contentsOfFile: path) else {
        print("Failed to load image from \(path)")
        return nil
    }

    guard let tiffData = image.tiffRepresentation,
          let bitmapRep = NSBitmapImageRep(data: tiffData) else {
        print("Failed to create bitmap representation from image")
        return nil
    }

    let width = Int(bitmapRep.size.width)
    let height = Int(bitmapRep.size.height)
    let bytesPerRow = bitmapRep.bytesPerRow

    guard let pixelData = malloc(bytesPerRow * height)?.assumingMemoryBound(to: UInt8.self) else {
        print("Failed to allocate memory for pixel data")
        return nil
    }

    // Copy the bitmap data to the allocated memory
    memcpy(pixelData, bitmapRep.bitmapData, bytesPerRow * height)
    print("Image data copied to memory")

    // 打印输入图像的长宽
    print("Input image dimensions: \(width) x \(height)")

    return (pixelData, width, height, bytesPerRow)
}

// 保存 PNG 图像的辅助函数
func savePNGImage(to path: String, pixelData: UnsafeMutablePointer<UInt8>?, width: Int, height: Int, bytesPerRow: Int) {
    guard let pixelData = pixelData else {
        print("Failed to save image: pixelData is nil")
        return
    }

    var pixelDataPointer: UnsafeMutablePointer<UInt8>? = pixelData

    // For RGBA image
    let bitmapRep = NSBitmapImageRep(bitmapDataPlanes: &pixelDataPointer,
                                     pixelsWide: width,
                                     pixelsHigh: height,
                                     bitsPerSample: 8,
                                     samplesPerPixel: 4,
                                     hasAlpha: true,
                                     isPlanar: false,
                                     colorSpaceName: .calibratedRGB,
                                     bitmapFormat: .alphaFirst,
                                     bytesPerRow: bytesPerRow,
                                     bitsPerPixel: 32)

    guard let bitmapRep = bitmapRep else {
        print("Failed to create NSBitmapImageRep")
        return
    }

    guard let pngData = bitmapRep.representation(using: .png, properties: [:]) else {
        print("Failed to generate PNG data")
        return
    }

    do {
        try pngData.write(to: URL(fileURLWithPath: path))
        print("Image saved successfully to \(path)")
    } catch {
        print("Failed to save image: \(error)")
    }
}

main()
