#!/bin/bash

# 设置项目根目录
PROJECT_DIR=$(pwd)
echo "Project directory: $PROJECT_DIR"

# 创建构建目录
BUILD_DIR="${PROJECT_DIR}/build"
echo "Creating build directory: $BUILD_DIR"
mkdir -p "${BUILD_DIR}"

# 清空构建目录
if [ -d "${BUILD_DIR}" ]; then
    echo "Cleaning previous build directory..."
    rm -rf "${BUILD_DIR}"/*
else
    echo "Build directory does not exist. Creating it..."
    mkdir -p "${BUILD_DIR}"
fi

# 检查构建目录是否创建成功
if [ ! -d "${BUILD_DIR}" ]; then
    echo "Failed to create build directory: $BUILD_DIR"
    exit 1
fi

# 进入构建目录
echo "Changing directory to: $BUILD_DIR"
cd "${BUILD_DIR}"

# 运行 CMake
echo "Running CMake..."
cmake ..

# 检查 CMake 是否成功
if [ $? -ne 0 ]; then
    echo "CMake failed. Exiting..."
    exit 1
fi

# 编译项目
echo "Compiling project..."
make -j$(sysctl -n hw.ncpu)

# 检查编译是否成功
if [ $? -ne 0 ]; then
    echo "Compilation failed. Exiting..."
    exit 1
fi

# 检查动态库是否生成
if [ ! -f "${BUILD_DIR}/libImage.dylib" ]; then
    echo "Dynamic library not found: ${BUILD_DIR}/libImage.dylib"
    exit 1
fi

# 输出构建结果
echo "Build completed. Dynamic library is in ${BUILD_DIR}/libImage.dylib"