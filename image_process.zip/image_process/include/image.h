#ifndef IMAGE_PROCESS_H
#define IMAGE_PROCESS_H

#include <opencv2/opencv.hpp>

class ImageProcess
{
public:
    cv::Mat getImageProcess(const cv::Mat &image);
};

#ifdef __cplusplus
extern "C"
{
#endif

    // 声明一个 C 链接的函数，返回原始指针
    extern "C" unsigned char *processImage(unsigned char *input, int width, int height, int bytesPerRow);

#ifdef __cplusplus
}
#endif

#endif