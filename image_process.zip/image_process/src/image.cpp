#include "image.h"

using namespace cv;
cv::Mat ImageProcess::getImageProcess(const cv::Mat &image)
{
    // 获取图像的宽度和高度
    int width = image.cols;
    int height = image.rows;

    // 计算矩形的左上角和右下角坐标
    int rectWidth = 150;  // 矩形的宽度
    int rectHeight = 50;  // 矩形的高度
    int startX = (width - rectWidth) / 2;  // 矩形的左上角 x 坐标
    int startY = (height - rectHeight) / 2;  // 矩形的左上角 y 坐标
    int endX = startX + rectWidth;  // 矩形的右下角 x 坐标
    int endY = startY + rectHeight;  // 矩形的右下角 y 坐标

    // 绘制矩形
    rectangle(image, Point(startX, startY), Point(endX, endY), Scalar(0, 255, 0), 4);  // 使用绿色绘制矩形，线条宽度为 2

    return image;
}

extern "C" unsigned char *processImage(unsigned char *input, int width, int height, int bytesPerRow)
{
    cv::Mat inputMat(height, width, CV_8UC4, input, bytesPerRow);
    ImageProcess imageProcess;
    cv::Mat outputMat = imageProcess.getImageProcess(inputMat);

    // 将输出 Mat 的数据复制到一个新的缓冲区
    unsigned char *outputData = new unsigned char[outputMat.total() * outputMat.elemSize()];
    std::memcpy(outputData, outputMat.data, outputMat.total() * outputMat.elemSize());

    return outputData;
}

extern "C" int add(int a, int b)
{
    return a + b;
}